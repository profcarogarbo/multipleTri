import matplotlib.animation as animation
from numpy import *
import matplotlib.pyplot as plt

spaceship=[[0, 0, 1, 1, 0], [1, 1, 0, 1, 1], [1, 1, 1, 1, 0], [0, 1, 1, 0, 0]]

def rulesOflife(celda,vecinos):
	# escriba desde aqui la respuesta  
            return 0


def evoluniverse(universe):
    newuniverse = copy(universe)
    for i in range(universe.shape[0]-2):
        for j in range(universe.shape[1]-2):
            celda=universe[i, j]
            vecinos=[universe[i-1,j],universe[i+1,j],universe[i,j-1],universe[i,j+1]]
            newuniverse[i, j] = rulesOflife(celda,vecinos)
    return newuniverse


def iniuniverse():
    #se define un universo de 50 por 50 celdas
    universe = zeros([50,50])

    # escriba desde aqui la respuesta

    # escriba hasta aqui la respuesta

    for j in range(0,3):
	# algunas de estas celdas estan vivas (con valor 1) y otras muertas (correspondientes con valor 0)
        for ke in range(0,5):
            universe[25+j][25+ke]=int(spaceship[j][ke])
            universe[5+j][5+ke]=int(spaceship[j][ke])
            universe[15+j][15+ke]=int(spaceship[j][ke])
            universe[20+j][20+ke]=int(spaceship[j][ke])
    return universe


# Animate
fig = plt.figure(dpi=200)
plt.axis("off")
ims = []
universe=iniuniverse()
for i in range(50):
    ims.append((plt.imshow(universe, cmap="Purples"),))
    universe = evoluniverse(universe)
    
    im_ani = animation.ArtistAnimation(fig, ims, interval=300, repeat_delay=5000, blit=True)
    
im_ani.save("figura.gif", writer="imagemagick")
