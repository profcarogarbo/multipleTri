
from sympy import Symbol
from sympy import solvers

x = Symbol('x')
print solve(x**2 - 1, x)
#[-1, 1]
