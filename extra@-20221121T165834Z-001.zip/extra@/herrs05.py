import numpy as np
from numpy import sin, cos,exp,sqrt
import matplotlib.pyplot as plt
from scipy.constants import pi


def mireal(uu, vv):
    arr = exp(uu)*cos(vv)
    return arr

def miima(uu, vv):
    arr= exp(uu)*sin(vv)
    return arr


def funo(x):
     arr=1/(x**2+1)
     return arr
 
def fdos(x):
     arr=x
     
     return arr
total =250   
delta = 0.025
x = np.linspace(-1.0, 3.0, total+1)
y = np.linspace(-2.0, 2.0, total+1)
#X, Y = np.meshgrid(x, y)
Z1 = np.exp(-x**2 - y**2)
#Z2 = np.exp(-(X - 1)**2 - (Y - 1)**2)
#Z = (Z1 - Z2) * 2
fp=open("dataCGB04.txt","w")
for i in range(len(x)):
	fp.write(str(x[i])+" "+str(y[i])+" "+str(Z1[i])+"\n")
fp.close()

X, Y = np.ogrid[-5:5:0.1, -5:5:0.1]
R = np.exp(-(X**2 + Y**2) / 15)

fig, (ax_jet, ax_gray) = plt.subplots(1, 2)
ax_jet.imshow(R, cmap='jet')
ax_gray.imshow(R, cmap='gray');

plt.show()
plt.gcf().clear()
fig, axes = plt.subplots(2, 2, figsize=(10, 10))

axes[0, 0].imshow(R, cmap='jet')
axes[0, 1].imshow(R, cmap='viridis')
axes[1, 0].imshow(R, cmap='magma')
axes[1, 1].imshow(R, cmap='gray');
plt.show()

random_image = np.random.random([500, 500])
random_image.shape
plt.imshow(random_image, cmap='gray', interpolation='nearest');
plt.show()
plt.imshow(random_image, cmap='jet', interpolation='nearest');
plt.show()
x=image[:,0]
y=image[:,1]
new=np.array(x,y)
new.shape()
plt.imshow(new, cmap='jet', interpolation='nearest');
plt.show()



uumax=20.0
uumin=-2.2
xx = np.linspace(uumin,uumax,total+1)
zz=funo(xx)
yy=fdos(xx)

