from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import cm
#https://drive.google.com/open?id=15bKNorNK6k0vKJkCDvaKkBSLq_FqiDEr
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

xs =[1,2,3,4,5,6,7,8,9,10]
ys =[5,6,2,3,13,4,1,2,4,8]
zs =[2,3,3,3,5,7,9,11,9,10]

xt =[-1,-2,-3,-4,-5,-6,-7,8,-9,-10]
yt =[-5,-6,-2,-3,-13,-4,-1,2,-4,-8]
zt =[-2,-3,-3,-3,-5,-7,9,-11,-9,-10]

ax.scatter(xs, ys, zs, c='r', marker='o')
ax.scatter(xt, yt, zt, c='b', marker='^')

ax.set_xlabel('X Label')
ax.set_ylabel('Y Label')
ax.set_zlabel('Z Label')

plt.show()

data = np.loadtxt("dataCGB03.txt")
print data
xs=data[:,0]
ys=data[:,1]
zs=data[:,2]
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

#print data.shape()
ax.scatter(xs, ys, zs, c='r', marker='o')
plt.show()

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

#print data.shape()
plt.plot(xs, ys, zs,solid_capstyle='butt')
plt.show()

# Plot the surface.
print "aqui viene"
fig = plt.figure()
ax = fig.gca(projection='3d')
surf = ax.plot_surface(xs, ys, zs, cmap=cm.coolwarm)#,                       linewidth=0, antialiased=False)
fig.colorbar(surf, shrink=0.5, aspect=5)
plt.show()



###############################################################################
# Create a simple contour plot with labels using default colors.  The
# inline argument to clabel will control whether the labels are draw
# over the line segments of the contour, removing the lines beneath
# the label

delta = 0.025
x = np.arange(-3.0, 3.0, delta)
y = np.arange(-2.0, 2.0, delta)
X, Y = np.meshgrid(x, y)
Z1 = np.exp(-X**2 - Y**2)
Z2 = np.exp(-(X - 1)**2 - (Y - 1)**2)
Z = (Z1 - Z2) * 2

print Z

fig, ax = plt.subplots()
CS = ax.contour(X, Y, Z)
ax.clabel(CS, inline=1, fontsize=10)
ax.set_title('Simplest default with labels')
plt.show()


fig = plt.figure()
ax = fig.gca(projection='3d')
surf = ax.plot_surface(X, Y, Z, cmap=cm.coolwarm,
                       linewidth=0, antialiased=False)
from matplotlib.ticker import LinearLocator, FormatStrFormatter
# Customize the z axis.
ax.set_zlim(-1.01, 1.01)
ax.zaxis.set_major_locator(LinearLocator(10))
ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=5)

plt.show()

#image = plt.imread('04_orca_killer_whale_gallery.png')

#plt.imshow(image)
#print (type(image), image.shape)
#im= plt.imshow(image, cmap='PuRd')
"""
============================
Clipping images with patches
============================

Demo of image that's been clipped by a circular patch.
"""
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import matplotlib.cbook as cbook
fig, ax = plt.subplots()
im = ax.imshow(image)
patch = patches.Circle((260, 200), radius=200, transform=ax.transData)
im.set_clip_path(patch)

ax.axis('off')
plt.show()
