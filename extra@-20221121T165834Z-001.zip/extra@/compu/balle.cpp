//programa segun ch2 pag 38, numerical
// balle- Program to compute the trajectory of a baseball using the Euler method

#include <iostream>
#include <fstream>
//#include <string>
#include <cmath>
#include <cstdlib> 
using namespace std;



float mynorm(float vecx, float vecy);
float posi(float pos,float velo,float tau);
float veli(float vel,float acce,float tau);


  int main ()
{
  cout << "comenzando";
  
  int maxsteps=1000;
  int tami=0; int counter=0; int i=0;

  //con arr[maxs][maxs]
  float arrxx[maxsteps];
  float arryy[maxsteps];
  float arrvx[maxsteps];
  float arrvy[maxsteps];
  float arrax[maxsteps];
  float array[maxsteps];
  
   //con arr[maxs][maxs]rungr kutta
  float rkarrxx[maxsteps];
  float rkarryy[maxsteps];
  float rkarrvx[maxsteps];
  float rkarrvy[maxsteps];
  float rkarrax[maxsteps];
  float rkarray[maxsteps];
 
  cout << "comenzando";
  
  float dragcoe=0.35;
  float rho=1.2; // air density Kg/m^3
  float area=4.3e-3; //cross-sectional area m^2
  float grav=9.81; //m/s^2
  float mass=0.145; //Kg
  
  float ere[2];
  float velo[2];
  float timeball=0.0001;
   
  cout << "Digite la posicion inicial en X:  en metros ";
  cin>>arrxx[0];
  
  cout << "Digite la posicion inicial en Y:  en metros ";
  cin>>arryy[0];
  
  cout << "Digite la velocidad inicial en X: en metros/seg ";
  cin>>arrvx[0];
  
  cout << "Digite la velocidad inicial en Y: en metros/seg ";
  cin>>arrvy[0];
  
  cout << "Digite el paso en el tiempo: en seg ";
  cin>>timeball;
  

  float airconst=-0.5*dragcoe*rho*area/mass; //air resistance constant

  float totalt=0.0;
  for(i=0;i<maxsteps;i++)
    {
      tami++;
      cout << "imprime dentro del for "<<endl;
      totalt+=timeball;
      //Euler
      
      arrax[i]=airconst*mynorm(arrvx[i],arrvy[i])*arrvx[i];
      array[i]=(airconst*mynorm(arrvx[i],arrvy[i])*arrvy[i])-grav;
cout << "pos velo acce "<< arryy[i]<<" "<<arrvy[i]<<" "<<array[i]<<endl;   
      arrxx[i+1]=arrxx[i]+(timeball*arrvx[i]);
      arryy[i+1]=arryy[i]+(timeball*arrvy[i]);
		 
      arrvx[i+1]=arrvx[i]+(timeball*arrax[i]);
      arrvy[i+1]=arrvy[i]+(timeball*array[i]);

      //Rungekuta 4to orden
      
      rkarrax[i]=airconst*mynorm(rkarrvx[i],rkarrvy[i])*rkarrvx[i];
      rkarray[i]=(airconst*mynorm(rkarrvx[i],rkarrvy[i])*rkarrvy[i])-grav;
      cout << "pos velo acce "<< arryy[i]<<" "<<arrvy[i]<<" "<<array[i]<<endl;   

      k2=posi(rkarrxx[i], rkarrvx[i]+(0.5*pos),velo,t+(timeball*0.5));
      k3=posi(pos,velo,t+(timeball*0.5));
      k4=posi(pos,velo,t+timeball);
      rksumfsx=rkarrxx[i]+(2*k2)+(2*k3)+k4;
      rksumfsy=rkarryy[i]+(2*k2)+(2*k3)+k4;
      
      rkarrxx[i+1]=rkarrxx[i]+(timeball/6.0*rksumfsx);
      rkarryy[i+1]=rkarryy[i]+(timeball/6.0*rksumfsy);

      k2=veli(vel,acce,tau);
      k3=veli(vel,acce,tau);
      k4=veli(vel,acce,tau);     
      rksumfsx=rkarrvx[i]+(2*k2)+(2*k3)+k4;
      rksumfsy=rkarrvy[i]+(2*k2)+(2*k3)+k4;
      
      rkarrvx[i+1]=rkarrvx[i]+(timeball/6.0*rksumfsx);
      rkarrvy[i+1]=rkarrvy[i]+(timeball/6.0*rksumfsy);
      
      
      
      /*
      //Euler Method
      arrrr[i+1][0]=arrrr[i][0]+(timeball*velo[0]);
      arrrr[i+1][1]=arrrr[i][1]+(timeball*velo[1]);
      
      arrvv[i+1][0]=arrvv[i][0]+(timeball*accel[0]);
      arrvv[i+1][1]=arrvv[i][1]+(timeball*accel[1]);
      */
            //break out of loop when ball hits the ground
      if (arryy[i+1] < 0)
	{
	  cout << "termino con  "<<tami<<" lineas";
	  i=maxsteps;
	}
      	
          }
  
  ofstream archsalida("secuenciaJordan.txt");   

  while(counter<tami)
     {
       archsalida<<arrxx[counter]<<" "<<arryy[counter]<<endl;
       counter++;
     }
 archsalida.close();
    
  
  return 5;
}




float mynorm(float vecx, float vecy){
  float uno=vecx*vecx;
  float dos=vecy*vecy;
  return sqrt(uno+dos);
}

float posi(float pos,float velo,float tau){
  return pos+(tau*velo)
}

float veli(float vel,float acce,float tau){
  return vel+(tau*acce)
}
