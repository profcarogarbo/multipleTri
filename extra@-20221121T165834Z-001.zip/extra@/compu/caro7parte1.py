#funcion de landau. Programa para filtrar usando solo FFT

import pylab
import matplotlib.pyplot as plt
import sys
import numpy as np
from math import cos,sqrt

def myamp(arr):
    newarr=[]
    for i in range (len(arr)):
        aux1=arr[i].real*arr[i].real
        aux2=arr[i].imag*arr[i].imag
        newarr.append(sqrt(aux1+aux2))
    return newarr

#filtrodependiendo de altura
def freqfilter(val,spectrum):
    myfilt=[]
    for ke in range(len(spectrum)):
        if spectrum[ke] > val:
            myfilt.append(spectrum[ke])
        else:
            myfilt.append(0)
    return myfilt
    
#Punto 1
fs = 0.10
nsamples=2000
T = nsamples*1.0/fs
t = np.linspace(0, T, nsamples, endpoint=False)
#y(t) = 3 cos(omega t) + 2 cos(3 omega t) + cos(5 omega t)
xuno=3*np.cos(64*0.75*t)
xdos=2*np.cos(3.0*64*0.75*t)
xtres=np.cos(5.0*64*0.75*t)
equis=xuno+xdos+xtres

equis=xuno+xdos+xtres
fftequno=np.fft.fft(xuno)
plt.plot(myamp(fftequno))
plt.show()

n = equis.size
timestep = 1/2.0
freq = np.fft.fftfreq(n, d=timestep)

plt.clf()
plt.plot(freq,myamp(fftequno))
plt.show()
myspec=myamp(fftequno)
print "max and index ", max(myspec),myspec.index(max(myspec))
print "frequency",freq[myspec.index(max(myspec))]




'''

plt.plot(xuno)
plt.show()
plt.clf()
plt.plot(xdos)
plt.show()
plt.clf()
plt.plot(xtres)
plt.show()
plt.clf()
equis=xuno+xdos+xtres
plt.plot(equis)
plt.show()


#np.fft.fft()

plt.clf()
plt.plot(np.fft.fft(xuno))
plt.show()
plt.clf()
plt.plot(np.fft.fft(xdos))
plt.show()
plt.clf()
plt.plot(np.fft.fft(xtres))
plt.show()
plt.clf()
'''
equis=xuno+xdos+xtres
fftequis=np.fft.fft(equis)
plt.plot(myamp(fftequis))
plt.show()

n = equis.size
timestep = 1/2.0
freq = np.fft.fftfreq(n, d=timestep)

plt.clf()
plt.plot(freq,myamp(fftequis))
plt.show()
myspec=myamp(fftequis)
print "max and index ", max(myspec),myspec.index(max(myspec))
print "frequency",freq[myspec.index(max(myspec))]



#doing filter 
sigfilt=freqfilter(2500,myspec)
plt.clf()
plt.plot(freq,sigfilt)
plt.show()

print "max and index ", max(sigfilt),myspec.index(max(sigfilt))
print "frequency",freq[myspec.index(max(sigfilt))]

plt.clf()
plt.plot(np.fft.ifft(sigfilt))
plt.show()

plt.clf()
plt.plot(xuno)
plt.show()
