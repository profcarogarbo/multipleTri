// programa para resolver la ecuacion de advencion ATCS pag 176
// usando el esquema FTCS : forward time centered space
//cin >> opc;
#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

int myarrpr(float xx[],float aaa[],int tam,char filename[])
{
  int mcount=0;
  std::cout <<std::endl;
  ofstream fp(filename);
  for(mcount=0;mcount<tam;mcount++)
    {
    std::cout <<aaa[mcount]<<" ";
    fp<<xx[mcount]<<" "<<aaa[mcount]<<endl;
    }
  return 0;
}



float pi=3.1416;  //CARO cambia esto
//float pi=PI;

float tau=0.2;  //paso del tiempo 0.002
#define ene 50       //number of grid points
float ele=1.0;    //system size - dimension
float ache=ele/ene; // grid spacing
float velo=1; // velocidad de la onda



// Condicion inicial, pulso Gaussian-cosine
float sigma=0.1; // ancho del pulso gausiano
float kwave=pi/sigma;  //numero de onda del coseno
float equis[ene];
float aaa[ene];
float anew[ene];

float equisnew[ene];

float aux1=0;




int main ()
{

  float coeff=-velo*tau/(2*ache); // coeficiente para el metodo FTCS

int mcount=0;
for(mcount=0;mcount<ene;mcount++)
  {
    equis[mcount]=(mcount-0.5)*ache-(ele/2);
    aux1=equis[mcount]*equis[mcount];
    aaa[mcount]=cos(kwave*equis[mcount])*exp(-aux1/(2*sigma*sigma));
     std::cout <<"equis i es"<<equis[mcount]<<std::endl;
  }
 
 std::cout <<"sale del for "<<std::endl;
 std::cout <<"equis es"<<equis<<std::endl;
// ciclo principal
 int tam=ene; //nstep;
 char name[20]="initial.txt";
 mcount=myarrpr(equis,aaa,tam,name);

 
 int nstep=int(ele/(velo*tau));
 int plotstep=int(nstep/50.);

 std::cout <<"el numero de pasos es "<<nstep<<std::endl;

 //hay que mover una grilla de 50
 int i=0;
 float allaaa[nstep][ene];
for(mcount=0;mcount<nstep;mcount++)
    { 
      coeff=-velo*tau*mcount/(2*ache); // coeficiente para el metodo FTCS
      equisnew[mcount]=+(tau*mcount)+equis[mcount];
for(i=0;i<ene;i++)
  {
 
 //frontera periodica cond.
    //baa method
    //anew[0]=aaa[0]+(coeff*(aaa[1]-aaa[ene-1]));
    anew[0]=(0.5*aaa[1]+aaa[ene-1])+(coeff*(aaa[1]-aaa[ene-1]));

   
   //for(i=0;i<nstep;i++)
   //  {
       std::cout <<"vamos en el "<<i<<std::endl;
       //bad method
       //      anew[i]=aaa[i+2]+(coeff*(aaa[i+3]-aaa[i+1]));

       //better method
       anew[i]=(0.5*(aaa[i+2]+aaa[i]))+(coeff*(aaa[i+2]-aaa[i]));
       // }
 //condiciones
 //anew[ene-1]=aaa[ene-1]+(coeff*(aaa[0]-aaa[ene-2]));
       anew[ene-1]=(0.5*(aaa[0]+aaa[ene-2]))+(coeff*(aaa[0]-aaa[ene-2]));
 
  }
//int j=0;
//for(j=0;j<ene;j++)
//  {
// allaaa[mcount][j]=anew[j];
//    }
    }

 char namefin[20]="final.txt";
 mcount=myarrpr(equisnew,anew,tam,namefin);

}
