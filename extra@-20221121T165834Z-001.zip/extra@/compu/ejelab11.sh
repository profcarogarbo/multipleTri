rm *txt
rm *jpg
rm a.out
g++ lab11PDE.cpp
./a.out
python plotxyDos.py
display grafica.jpg &
cp inicial.txt inicialcero.txt
cp final.txt finalcero.txt
cp inicialnorm.txt inicial.txt 
cp finalnorm.txt final.txt
cp grafica.jpg grafic.jpg
python plotxyDos.py
mv grafica.jpg grafnormal.jpg
display grafnormal.jpg
