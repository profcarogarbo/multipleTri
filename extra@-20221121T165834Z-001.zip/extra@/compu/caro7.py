#funcion de landau. Programa para filtrar usando solo FFT

import pylab
import matplotlib.pyplot as plt
import sys
import numpy as np
from math import cos,sqrt
from scipy.io import wavfile as wav


def myamp(arr):
    newarr=[]
    for i in range (1,len(arr)):
        aux1=arr[i].real*arr[i].real
        aux2=arr[i].imag*arr[i].imag
        newarr.append(sqrt(aux1+aux2))
    return newarr

def arraytoinv(value,arr):
    newarr=[]
    for i in range (1,len(arr)):
        aux1=arr[i].real*arr[i].real
        aux2=arr[i].imag*arr[i].imag
        mynorm=sqrt(aux1+aux2)
        if mynorm >value:
            print "caso mayor"
            newarr.append(arr[i])
        else:
            num=0.+0.j
            newarr.append(num)
    return np.array(newarr)  

#filtrodependiendo de altura
def freqfilter(val,spectrum):
    myfilt=[]
    myfilt.append(0)
    for ke in range(1,len(spectrum)):
        if spectrum[ke] > val:
            myfilt.append(spectrum[ke])
        else:
            myfilt.append(0)
    return myfilt
    
#Punto 1
fs = 0.10
nsamples=2000
T = nsamples*1.0/fs
t = np.linspace(0, T, nsamples, endpoint=False)
#y(t) = 3 cos(omega t) + 2 cos(3 omega t) + cos(5 omega t)
xuno=3*np.cos(64*0.75*t)
xdos=2*np.cos(3.0*64*0.75*t)
xtres=np.cos(5.0*64*0.75*t)
equis=xuno+xdos+xtres



#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$


rate, data = wav.read('modem.wav')
fftequis=np.fft.fft(data[:,0])
print fftequis
plt.plot(myamp(fftequis))
plt.show()

n = data.size
timestep = 1/2.0
freq = np.fft.fftfreq(n, d=timestep)

plt.clf()
plt.plot(myamp(fftequis))
plt.show()
myspec=myamp(fftequis)
#print myspec
print "max and index ", max(myspec),myspec.index(max(myspec))
print "frequency",freq[myspec.index(max(myspec))]



#doing filter 
sigfilt=freqfilter(0.2e8,myspec)
plt.clf()
plt.plot(sigfilt)
plt.show()

filsig=arraytoinv(0.2e8,fftequis)
print fftequis
print filsig
wav.write('mesignalIN.wav',rate,data[:,0].astype(data.dtype))
wav.write('mesignalOUT.wav',rate,np.fft.ifft(filsig).astype(data.dtype))
