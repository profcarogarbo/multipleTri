// programa para resolver la ecuacion de advencion
// usando el esquema FTCS : forward time centered space

#include <iostream>
#include <array>
#include <stdio.h>
#include <vector>
#include <fstream>
#include <cmath>
#include <algorithm> // std::min_element, std::max_element
using namespace std;


//impresion de archivo sin normalizar
int myarrpr(std::vector<float> xx,std::vector<float> aaa,int tam,char filename[])
{
  ofstream fp(filename);
  for(int mcount=0;mcount<tam;mcount++)
        fp<<xx[mcount]<<" "<<aaa[mcount]<<endl;
     return 0;
}

//impresion de archivo normalizada
int myarrprnorm(std::vector<float> xx,std::vector<float> aaa,int tam,char filename[])
{
  float maxval=*std::max_element(aaa.begin(),aaa.end());
  //float maxval=aaa.max();
  ofstream fp(filename);
  for(int mcount=0;mcount<tam;mcount++)
    fp<<xx[mcount]<<" "<<aaa[mcount]/maxval<<endl;
    
  return 0;
}

#define ene 50 //number of grid points
#define pi 3.1416



int main ()
{
float tau=0.00015;  //paso en el tiempo      
float ele=1.0;    //system size - dimension
float ache=ele/ene; // grid spacing
float velo=1; // velocidad del flujo
 float aux2=0;
 

// Condicion inicial, pulso Gaussian-cosine
float sigma=0.1; // ancho del pulso gausiano
float kwave=pi/sigma;  //numero de onda del coseno


float equisarr[ene];
float aaaarr[ene];
//float anew[ene];
//float equisnew[ene];
///float afin[ene];
//float equisfin[ene];
 
 std::vector<float> aaa (ene); 
std::vector<float> equis (ene);
 std::vector<float> anew (ene); 
std::vector<float> equisnew (ene);
std::vector<float> afin (ene);
 std::vector<float> equisfin (ene);

  int tam=ene;
  float coeff=-velo*tau/(2*ache); // coeficiente para el metodo FTCS
  int i=0;
  int mcount=0;
  float aux1=0;



  
for(mcount=0;mcount<ene;mcount++)
  {
    equisarr[mcount]=(mcount-0.5)*ache-(ele/2);
    aux1=equisarr[mcount]*equisarr[mcount];
    aaaarr[mcount]=cos(kwave*equisarr[mcount])*exp(-aux1/(2*sigma*sigma));
 
   }
 aaa.assign(aaaarr, aaaarr+ene);
 equis.assign(equisarr, equisarr+ene);
 
 anew.assign(aaaarr, aaaarr+ene);
 equisnew.assign(equisarr, equisarr+ene);
 
 afin.assign(aaaarr, aaaarr+ene);
 equisfin.assign(equisarr, equisarr+ene);

 
 std::cout <<"equis "<<equis.at(30)<<std::endl;
 std::cout <<"anew "<<anew.at(30)<<std::endl;


 
// ciclo principal

 int nstep=int(ele/(velo*tau));
 
 std::cout <<"el numero de pasos en el tiempo es "<<nstep<<std::endl;

  for(mcount=0;mcount<500;mcount++)
    {

      std::cout <<"equisfin "<<equisfin.at(30)<<std::endl;
      std::cout <<"afin "<<afin.at(30)<<std::endl;


      coeff=-velo*tau/(2.0*ache); // coeficiente para el metodo FTCS
          //frontera periodica
      aux2=((anew.at(2)+anew.at(ene-1))-(2.0*anew.at(1)))*2.0*coeff*coeff;
      afin.at(1)=anew.at(1)+(coeff*(anew.at(2)-anew.at(ene-1)))+aux2;
      
      
      equisfin.at(0)=(velo*tau)+equisnew.at(0);
      
      for(i=1;i<ene-1;i++)
	{
	  aux2=((anew.at(i+1)+anew.at(i-1))-(2.0*anew.at(i)))*2.0*coeff*coeff;
	  afin.at(i)=anew.at(i)+(coeff*(anew.at(i+1)-anew.at(i-1)))+aux2;
	  equisfin.at(i)=(velo*tau)+equisnew.at(i);

	}
     
       //frontera periodica
      aux2=((anew.at(0)+anew.at(ene-2))-(2.0*anew.at(ene-1)))*2.0*coeff*coeff;
      afin.at(ene-1)=anew.at(ene-1)+(coeff*(anew.at(0)-anew.at(ene-2)))+aux2;
      
      equisfin.at(ene-1)=(velo*tau)+equisnew.at(ene-1);

      
      //haciendo que equis sea periodica
      for(int ke=1;ke<ene;ke++)
	if(equisfin.at(ke)>=0.5*ele)
	  equisfin.at(ke)-=ele;

      cout<<" aafter "<<anew.at(30);
      //avance

      
      for(int j=1;j<ene;j++)
	{
	  equisnew.at(j)=equisfin.at(j);
	  anew.at(j)=afin.at(j);
	  }
      cout<<" anew "<<anew.at(30)<<" afin "<<afin.at(30)<<endl;
      
      if (mcount == 15)
      	{
      	  cout<<"escribiendo archivo intermedio"<<endl;
	  //	  char newfin[20]="newmitad.txt";
      //  int pe=myarrpr(equisfin,afin,tam,newfin);
       }
    }


  char name[20]="inicial.txt";
 mcount=myarrpr(equis,aaa,tam,name);
 char namedos[30]="inicialnorm.txt";
 mcount=myarrprnorm(equis,aaa,tam,namedos);
 char namefin[20]="final.txt";
 mcount=myarrpr(equisfin,afin,tam,namefin);
 char namefinnorm[50]="finalnorm.txt";
 mcount=myarrprnorm(equisfin,afin,tam,namefinnorm);

}
