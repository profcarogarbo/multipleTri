// programa para resolver la ecuacion PDE como el enunciado lab12
// usando el esquema FTCS : forward time centered space

#include <iostream>
#include <fstream>
#include <cmath>
#include <algorithm> // std::min_element, std::max_element
using namespace std;


//impresion de archivo sin normalizar
int myarrpr(float xx[],float aaa[],int tam,char filename[])
{
  int mcount=0;
  std::cout <<std::endl;
  ofstream fp(filename);
  for(mcount=0;mcount<tam;mcount++)
        fp<<xx[mcount]<<" "<<aaa[mcount]<<endl;
     return 0;
}

//impresion de archivo normalizada
int myarrprnorm(float xx[],float aaa[],int tam,char filename[])
{
  int mcount=0;
  float maxval=*std::max_element(aaa,aaa+tam);
  std::cout <<std::endl;
  ofstream fp(filename);
  for(mcount=0;mcount<tam;mcount++)
    fp<<xx[mcount]<<" "<<aaa[mcount]/maxval<<endl;
    
  return 0;
}

float tau=0.0015; //0.0001;  //paso en el tiempo 
#define ene 10       //number of grid points. Debe ser par
float ele= 1500.0;    //system size - dimension
float ache=ele/ene; // grid spacing
float vmax=90.0; // velocidad maxima de un carro en m/s


// Condicion inicial, pulso cuadrado
float rhomax=4.0; 

int nstep=700;//int((ele/4.0)/(vmax*tau)); //es 1388


float equis[ene];
float rhoini[ene];
float rho[ene];
float rhofin[ene];
float flow[ene];

float aux1=0;


int main ()
{
  int tam=ene;
  float coeff=tau/(2*ache); // coeficiente para el metodo FTCS traffic
  int i=0;
  int mcount=0;
  for(mcount=0;mcount<ene;mcount++)
    rho[mcount]=0.0;
  
 for(mcount=0;mcount<ene;mcount++)
   equis[mcount]=(mcount-0.5)*ache-(ele/2.0);

  for(mcount=ene/4;mcount<((ene*0.5)-1);mcount++)
    rho[mcount]=rhomax;

   rho[ene/2]=rhomax/2.0;//try running without this line
  
//guardando rho inicial
  for(int ke=0;ke<ene;ke++)
    rhoini[ke]=rho[ke];

 
// ciclo principal

  

 std::cout <<"el numero de interacciones es "<<nstep<<std::endl;

  for(mcount=0;mcount<nstep;mcount++)
    {
      
      for(i=0;i<ene;i++)
	flow[i]=rho[i]*(vmax*(1-(2.0*rho[i]/rhomax)));

          //frontera periodica
      rhofin[0]=rho[0]-(coeff*(flow[1]-flow[ene-1]));
			
      for(i=1;i<ene-1;i++)
	rhofin[i]=rho[i]-(coeff*(flow[i+1]-flow[i-1]));
     
       //frontera periodica
      rhofin[ene-1]=rho[ene-1]-(coeff*(flow[0]-flow[ene-1]));
      
      //avance
      for(int ke=0;ke<ene;ke++)
	if (rho[ke] > 0)
	  rho[ke]=rhofin[ke];
	else
	  rho[ke]=0.5;
    }	 
			
  
 char name[20]="inicial.txt";
 mcount=myarrpr(equis,rhoini,tam,name);
 
 char namefin[20]="final.txt";
 mcount=myarrpr(equis,rhofin,tam,namefin);

 
 char namedos[30]="inicialnorm.txt";
 mcount=myarrprnorm(equis,rhoini,tam,namedos);
 char namefinnorm[20]="finalnorm.txt";
 mcount=myarrprnorm(equis,rhofin,tam,namefinnorm);
 
}
