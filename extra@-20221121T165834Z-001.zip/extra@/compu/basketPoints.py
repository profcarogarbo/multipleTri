import numpy as np
from numpy import sin, cos
from math import sqrt
from scipy.constants import g


def regular(r_0, v, th, t):
    v_0 = [v*cos(th), v*sin(th)]
    x = r_0[0] + v_0[0]*t
    y = r_0[1] + v_0[1]*t -0.5*g*t**2
    return x, y

def calyee(yo,vy,t):
    y=[]
    for i in range(len(t)+10):
        if i < 10 :
            y.append(yo)
        else:
            y.append(yo + vy*(t[i-10]) -0.5*g*(t[i-10])**2)
            
    return y

def calyee1(yo,vy,t):
    y=[]
    for i in range(len(t)+20):
        if i < 20 :
            y.append(yo)
        else:
            y.append(yo + vy*(t[i-20]) -0.5*g*(t[i-20])**2)
            
    return y

def calyeefail(yo,vy,t):
    y=yo + (vy*t)-(0.5*g*t**2)
            
    return y

def calyee3(yo,vy,t):
    y=[]
    for i in range(len(t)):
        y.append(yo + (vy*t[i]) -(0.5*g*(t[i]**2)))            
    return y


def caleex(xo,vx,t):
    x=[]
    for i in range(len(t)):
        x.append(xo + (vx*t[i]) )            
    return x
N = 50
tmax=1.5
t = np.linspace(0, tmax, 51)
print t
r_0=[0.0,2.0]
v=130
th=0.35 #0.44  #25 #0.84 48  # 35 0.61 # 53 fail 0.93 
v=sqrt(1000*g/sin(2*th))
voy=(3.05+(0.5*g*tmax**2)-2.0)/tmax   
#x_f, y_f = regular(r_0, v, th, t)
y_f=calyee3(2.5,voy,t)

vox=(5.5)/tmax   
#x_f, y_f = regular(r_0, v, th, t)
x_f=caleex(0.0,vox,t)
print x_f,y_f

print y_f
fp=open("ejey3points.txt","w")
for i in range(len(y_f)):
	fp.write(str(y_f[i])+"\n")

fp.close()
fp=open("ejexpoints.txt","w")
for i in range(len(x_f)):
	fp.write(str(x_f[i])+"\n")

fp.close()

tmax=tmax-0.10
t = np.linspace(0, tmax, 51-10)

voy=(3.05+(0.5*g*(tmax)**2)-2.0)/(tmax)   
#x_f, y_f = regular(r_0, v, th, t)
y_f=calyee(2.0,voy,t)
fp=open("ejey2points.txt","w")
for i in range(len(y_f)):
	fp.write(str(y_f[i])+"\n")
fp.close()

print "2 points",y_f


tmax=tmax-0.10
t = np.linspace(0, tmax, 51-20)

voy=(3.05+(0.5*g*(tmax)**2)-2.0)/(tmax)   
#x_f, y_f = regular(r_0, v, th, t)
y_f=calyee1(2.0,voy,t)
fp=open("ejey1points.txt","w")
for i in range(len(y_f)):
	fp.write(str(y_f[i])+"\n")
fp.close()

print "1 points",y_f

tmax=2.0
t = np.linspace(0, tmax, 51)
voy=(1.0+(0.5*g*tmax**2)-1.0)/tmax   
#x_f, y_f = regular(r_0, v, th, t)
y_f=calyeefail(1.0,voy,t)

print y_f
fp=open("ejeyFailpoints.txt","w")
for i in range(len(y_f)):
	fp.write(str(y_f[i])+"\n")
fp.close()

print "fail points",y_f
